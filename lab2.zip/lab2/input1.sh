#!/bin/bash
echo 'Enter your name: '
read name
echo "Hello, $name"

