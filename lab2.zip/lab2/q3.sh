#!/bin/bash
pass="123"
echo "Hello.... Type your password"
read pwd
if [ $pwd == $pass ];
then echo "Access Granted"
else echo "Access Denied"
fi;

