#!/bin/bash
echo "Enter the number : "
read number
if [ $((number % 2)) -eq 0 ];
then echo "Even Number"
else echo "Odd number"
fi
