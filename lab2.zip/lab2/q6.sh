#!/bin/bash
echo "Enter the number : "
read number
if [ $((number)) -lt 0 ];
then echo "Number is Negative"
elif [ $((number)) -gt 0 ];
then echo "Number is Positive"
else echo "Given Number is Zero"
fi
