#!/bin/bash
echo "Enter the number : "
read number
echo "Calculating Factorial ----"
fact=1
while [ $((number)) -gt 0 ];
do 
	fact=$((fact*number));
	let number--;
done
echo "Factorial of the given number = $fact"
