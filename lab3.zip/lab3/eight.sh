#!/bin/bash

username="admin"
pass="123"

read -p "Enter username : " u
read -sp "Enter password : " p
echo
if [[ $u == $username && $p == $pass ]];
then
	echo "Login Successfully"
else
	echo "Invalid credentials"
fi
