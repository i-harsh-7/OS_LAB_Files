#!/bin/bash

read -p "Enter output filename : " out
cat *.txt > "$out"
echo "Files merged into $out"
