#!/bin/bash
echo -e "Current Date and Time:\n$(date)"
