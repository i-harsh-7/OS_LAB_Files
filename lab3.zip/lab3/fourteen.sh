#!/bin/bash

read -p "Enter filename : " file
sort "$file" | uniq
