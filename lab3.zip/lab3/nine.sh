#!/bin/bash

read -p "Enter seconds : " s
while [ $s -gt 0 ];
do
	echo "$s"
	sleep 1
	let s--
done
echo "Time's up!!!"
