#!/bin/bash

read -p "Enter source directory: " src
read -p "Enter destination directory: " dest
timestamp=$(date +%Y%m%d_%H%M%S)
mkdir -p "$dest/backup_$timestamp"
cp "$src"/*.txt "$dest/backup_$timestamp"
echo "Backup Completed"
