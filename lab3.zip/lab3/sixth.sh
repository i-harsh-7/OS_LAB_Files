#!/bin/bash

read -p "Enter Directory path: " dir
du -sh "$dir"
