#!/bin/bash

read -p "Enter folder path : " folder
read -p "Enter prefix : " pre
cd "$folder" || exit
for file in *.txt;
do
	mv "$file" "${pre}_$file"
done
echo "Renamin Complete!!!!"
