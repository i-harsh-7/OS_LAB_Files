#!/bin/bash

read -p "Enter log filename : " log
read -p "Enter keyword : " key
grep "$key" "$log"
