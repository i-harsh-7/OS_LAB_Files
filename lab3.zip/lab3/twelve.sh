#!/bin/bash

read -p "Enter search term : " se
read -p "Enter replacement : " rp
for file in *.txt;
do
	sed -i "s/$se/$rp/g" "$file"
done

echo "Replacement Done !!!"
	
