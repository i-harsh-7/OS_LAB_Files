#!/bin/bash

read -p "Enter first number : " a
read -p "Enter second number : " b

echo "Addition: $((a+b))"
echo "Subtraction: $((a-b))"
echo "Multiplication: $((a*b))"
echo "Division: $((a/b))"
