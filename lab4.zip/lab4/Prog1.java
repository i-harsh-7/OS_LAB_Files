import java.util.*;
import java.lang.*;

public class Prog1{

	 static class Process{
		String pName;
		int bt;
		
		Process(String x, int y){
			pName = x;
			bt = y;
		}
	}
	
	static int t;
	static double avg_wt;
	
	public static void main(String[] args){
		
		
		Scanner sc = new Scanner(System.in);
	
		List<Process> list = new ArrayList<>();
		
		System.out.print("Enter the number of processes : ");
		int n = sc.nextInt();
		
		System.out.println("Enter the details about processes");
		int N=n;
		while(N>0){
			System.out.print("Enter process Name - ");
			String p = sc.next();
			
			System.out.print("Enter burst time of the process - ");
			int temp = sc.nextInt();
			
			list.add(new Process(p, temp));
			N--;
		}
		
		int wait[] = new int[n];
		String schedule[] = schedule(list, wait, n);
		
		for(int i=0; i<n; i++){
			avg_wt += wait[i];
		}
		System.out.println("");
		
		System.out.println("The total time for execution = " + t);
		avg_wt = avg_wt/n;
		System.out.println("The average waiting time = " + avg_wt);
		
		sc.close();
	}
	
	public static String[] schedule(List<Process> list, int wait[], int n){
		String[] sch = new String[n];
		
		for(int i=0; i<n; i++){
			Process demo = list.get(i);
			
			String p = demo.pName;
			sch[i] = p;
			wait[i] = t;
			t += demo.bt;

		}
		return sch;
	}
}











