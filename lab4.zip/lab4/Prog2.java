import java.util.*;
import java.lang.*;

public class Prog2{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter the total number of processes : ");
		int n = sc.nextInt();
		
		double alpha = 0.5;
		double alpha_not = 1 - alpha;
		
		double[] tau_val = new double[n+1];
		tau_val[0] = 10;
		
		int time_val[] = new int[n+1];
		
		System.out.println("Enter the actual time value of processes : ");
		
		for(int i=1; i<=n; i++){
			time_val[i] = sc.nextInt();
		}
		
		for(int i=1; i<=n; i++){
			tau_val[i] = alpha*time_val[i-1] + alpha_not*tau_val[i-1];
		}
		
		System.out.println("Value of Tau are ");
		
		for(int i=0; i<=n; i++){
			System.out.println("Tau " + i + " " + tau_val[i]);
		}
		
		sc.close();
	}

}
