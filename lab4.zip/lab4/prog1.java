import java.util.*;
import java.lang.*;

public class Main{

	 static class Process{
		String pName;
		String bt;
		
		Process(String x, int y){
			pName = x;
			bt = y;
		}
	}

	int t = 0;
	int avg_wt = 0;
	
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
	
		List<Process> list = new ArrayList<>();
		
		int n = sc.nextInt();
		System.out.println("Enter the details about processes");
		
		while(n>0){
			System.out.print("Enter process Name - ");
			String a = sc.next();
			
			System.out.print("Enter burst time of the process - ");
			int temp = sc.nextInt();
			
			list.add(new Process(s, temp));
			n--;
		}
		
		System.out.println(list);
		
		sc.close();
	}
}
