import java.util.*;
import java.lang.*;

class Process{
	String p_name;
	int at, bt, ct, tat, wt;
	
	Process(String p_name, int at, int bt){
		this.p_name = p_name;
		this.at = at;
		this.bt = bt;
		ct = 0;
		tat = 0;
		wt = 0;
	}
	
	@Override
	public String toString(){
		return String.format("Process %s , AT : %d, BT : %d, CT : %d, TAT : %d, WT : %d", 						p_name, at, bt, ct, tat, wt);
	}
}

public class SJF{
	public static void main(String abcd[]){
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter the number of processes : ");
		int n = sc.nextInt();
		
		int totalTime = 0, waitTime = 0, tatTime = 0;
		List<Process> pr = new ArrayList<>();
		
		List<String> schedule = new ArrayList<>();
		
		
		System.out.println("Enter the details of the processes");
		for(int i=0; i<n; i++){
			System.out.print("\nEnter the name of the process : ");
			String str = sc.next();
			
			System.out.print("Enter the arrival time of the process : ");
			int at = sc.nextInt();
			
			System.out.print("Enter the burst time of the process : ");
			int bt = sc.nextInt();
			
			pr.add(new Process(str, at, bt));
		}
		
		List<Process> sort_pr = new ArrayList<>(pr);
		Collections.sort(sort_pr, Comparator.comparingInt(p -> p.at));
		
		Queue<Process> rq = new PriorityQueue<>(Comparator.comparingInt(p -> p.bt));
		rq.offer(sort_pr.get(0));
		sort_pr.remove(0);
		
		int time = 0;
		while(!rq.isEmpty()){
			Process p = rq.poll();
			
			//time += p.at;
			time = totalTime;
			totalTime += p.bt;
			schedule.add(p.p_name);
			
			p.ct = time + p.bt;
			p.tat = p.ct - p.at;
			p.wt = p.tat - p.bt;
			
			waitTime += p.wt;
			tatTime += p.tat;
			
			while(sort_pr.size()>0 && time <= totalTime){
				rq.offer(sort_pr.remove(0));
			}
			
			if(rq.isEmpty() && sort_pr.size() > 0){
				Process q = sort_pr.get(0);
				time += q.at;
				rq.offer(q);
				sort_pr.remove(0);
			}
		}
		
		System.out.println("\nAfter complete execution of the processes : ");
		for(Process p : pr){
			System.out.println(p);
		}
	
		System.out.println("\n Scheduling of the process in the order as : ");
		System.out.println(schedule);

		System.out.println("Average waiting time = " + waitTime/(float)n);
		System.out.println("Averate Turn Around Time = " + tatTime/(float)n);
		
		sc.close();
	}
}


