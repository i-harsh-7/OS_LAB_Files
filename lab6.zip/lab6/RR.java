package RoundRobin;

import java.util.*;
import java.lang.*;


public class RR{

	public static void main(String[] abcd){
		//System.out.println();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("--------- Round Robbin Algorithm ----------\n");
		
		System.out.print("Enter the number of processes : ");
		int n = sc.nextInt();
		
		System.out.print("Enter the time quantum : ");
		int tq = sc.nextInt();
		
		List<Process> pr = new ArrayList<>();
		
		for(int i=0; i<n; i++){
			System.out.print("\nEnter the name of the process : ");
			String p_name = sc.next();
			
			System.out.print("Enter the arrival time : ");
			int at = sc.nextInt();
			
			System.out.print("Enter the burst time : ");
			int bt = sc.nextInt();
			
			pr.add(new Process(p_name, at, bt));
		}
		
		List<Process> sort_pr = new ArrayList<>(pr);
		Collections.sort(sort_pr, Comparator.comparingInt(p -> p.at));
		
		int comp = 0, time = 0, idx = 0;
		float avgWT = 0, avgTAT = 0;
		
		List<String> sch = new ArrayList<>();
		
		while(comp < n){
			if(idx >= sort_pr.size())	idx = 0; 
    			
			Process p = sort_pr.get(idx%n);
			
			if(p.at > time)	time = p.at;
    			
			int slice = p.rem_bt - tq;
			sch.add(p.p_name);
			
    			if(slice <= 0){
        			time += p.rem_bt;
        			p.rem_bt = 0;

        			p.ct = time;
        			p.tat = p.ct - p.at;
       			p.wt = p.tat - p.bt;

        			avgWT += p.wt;
        			avgTAT += p.tat;

        			sort_pr.remove(idx);
        			comp++;
        		}
        
    			else {
        			time += tq;
        			p.rem_bt -= tq;
        			idx++; 
    			}
		}
		
		System.out.println();
		
		for(Process p : pr){
			System.out.println(p);
		}
		
		System.out.println("\nScheduling of the processes : ");
		for(String s : sch){
			System.out.print(s + " | ");
		}
		
		avgWT = avgWT/(float)n;
		avgTAT = avgTAT/(float)n;
		System.out.println();
		
		System.out.println("Average waiting time = " + avgWT);
		System.out.println("Average turn around time = " + avgTAT);
		
		sc.close();
	}
}



class Process{
		String p_name;
		int at, bt, rem_bt, ct, wt, tat;
	
		Process(String p_name, int at, int bt){
			this.p_name = p_name;
			this.at = at;
			this.bt = bt;
			rem_bt = bt;
			ct = 0;
			tat = 0; 
		}
	
		@Override
		public String toString(){
			return String.format("Process Name = %s : AT = %d : BT = %d : CT = %d : WT = %d : TAT : %d", p_name, at, bt, ct, wt, tat);
		}
	}

