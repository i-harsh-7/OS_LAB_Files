import java.util.*;
import java.lang.*;

class Process{
	String p_name;
	int at, bt, ct, tat, wt, pr, rem_bt;
	
	Process(String p_name, int at, int bt,int pr){
		this.p_name = p_name;
		this.at = at;
		this.bt = bt;
		this.pr = pr;
		this.rem_bt = bt;
		ct = 0;
		tat = 0;
		wt = 0;
	}
	
	@Override
	public String toString(){
		return String.format("Process Name = %s : AT = %d : BT = %d : PR = %d : CT = %d : WT = %d : TAT = %d", p_name, at, bt, pr, ct, wt, tat);
	}
}

class MLQS{
	public static void main(String abcd[]){
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter the number of processes : ");
		int n = sc.nextInt();	
		
		List<Process> pro = new ArrayList<>();
		List<Process> high = new ArrayList<>();
		List<Process> low = new ArrayList<>();
		
		//PriorityQueue<Process> high = new PriorityQueue<>(Comparator.comparingInt(p -> p.at));
		//PriorityQueue<Process> low = new PriorityQueue<>(Comparator.comparingInt(p -> p.at));
		
		for(int i=0; i<n; i++){
			System.out.print("\nEnter the name of the process : ");
			String p_name = sc.next();
			
			System.out.print("Enter the arrival time : ");
			int at = sc.nextInt();
			
			System.out.print("Enter the burst time : ");
			int bt = sc.nextInt();
			
			System.out.print("Enter the priority : ");
			int pr = sc.nextInt();
			
			Process p = new Process(p_name, at, bt, pr);
			pro.add(p);
			
			if(pr == 1) high.add(p);
			else low.add(p);
		}
		
		Collections.sort(high, Comparator.comparingInt(p -> p.at));
		Collections.sort(low, Comparator.comparingInt(p -> p.at));
		
		List<String> sch = new ArrayList<>();
		
		
		System.out.print("\nEnter the time quantum for the round robbin : ");
		int tq = sc.nextInt();
		
		int comp = 0, time = 0, idx1 = 0, idx2 = 0, avgWT= 0, avgTAT=0, nextTime = 0;
		
		while(comp <n){ 
			while(high.size() > 0){
				if(idx1 >= high.size())	idx1 = 0; 
    			
				Process p = high.get(idx1%high.size());
			
				if(p.at > time){
					nextTime = p.at;
					break;
				}	
    			
				int slice = p.rem_bt - tq;
				sch.add(p.p_name);
			
    				if(slice <= 0){
        				time += p.rem_bt;
        				p.rem_bt = 0;

        				p.ct = time;
        				p.tat = p.ct - p.at;
       				p.wt = p.tat - p.bt;

        				avgWT += p.wt;
        				avgTAT += p.tat;

        				high.remove(idx1);
        				comp++;
        			}
        
    				else {
        				time += tq;
        				p.rem_bt -= tq;
        				idx1++; 
    				}
			}
			
			while(low.size() > 0){
				if(idx2 >= low.size())	idx2 = 0; 
				
				Process p = low.get(idx2%low.size());
				int next = p.at+1;
				
				if(high.size() >0){
					next = high.get(0).at;
				}
				if(p.at < next){
					time += p.bt;
					sch.add(p.p_name);
					
					p.ct = time;
					p.tat = p.ct - p.at;
					p.wt = p.tat - p.bt;
					
					avgWT += p.wt;
        				avgTAT += p.tat;
        				
        				low.remove(idx2);
        				comp++;
				}
				else{
					break;
				}
			}
		}
		
		System.out.println();
		
		System.out.println("Scheduliing of the process");
		for(String s : sch){
			System.out.print(s + " -> ");
		}
		
		System.out.println();
		System.out.println("\nAverage Waiting Time = " + avgWT/(float)n);
		System.out.println("Average Turn Around Time = " + avgTAT/(float)n);
	}
}
















