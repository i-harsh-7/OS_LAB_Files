import java.util.*;
import java.lang.*;


class Resources{
	int a, b, c;
	
	Resources(int a, int b, int c){
		this.a = a;
		this.b = b;
		this.c = c;
	}
}

class Process{
	String p_name;
	Resources allot, max, need;
	
	Process(String p_name, Resources allot, Resources max, Resources need){
		this.p_name = p_name;
		this.allot = allot;
		this.max = max;
		this.need = need;
	}
	
}
	


public class BankersAlgo{
	public static void main(String[] abcd){
		Scanner sc = new Scanner(System.in);
		
		//System.out.println();
		//System.out.print();
		
		System.out.println("----------------Bankers Algorithm--------------------\n");
		
		System.out.print("Enter the available instance of three resources : ");
		int A = sc.nextInt();
		int B = sc.nextInt();
		int C = sc.nextInt();
		
		Resources total = new Resources(A, B, C);
		System.out.println("\nTotal resources is : ");
		System.out.println("A : " + total.a + " | B : " + total.b + " | C : " + total.c);
		
		System.out.print("\n Enter the number of processes : ");
		int n = sc.nextInt();
		int a=0,b=0,c=0;
		
		List<Process> pr = new ArrayList<>();
		List<String> sch = new ArrayList<>();
		
		for(int i=0; i<n; i++){
			System.out.print("\nEnter the name of the process : ");
			String p_name = sc.next();
			
			System.out.print("Enter allotted instance of three resources : ");
			int x = sc.nextInt();
			int y = sc.nextInt();
			int z = sc.nextInt();
			
			a +=x;	b += y;  c += z;
			
			Resources allot = new Resources(x, y, z);
			
			System.out.print("Enter max instance of three resources : ");
			int u = sc.nextInt();
			int v = sc.nextInt();
			int w = sc.nextInt();
			
			Resources max = new Resources(u, v, w);
			
			if(x>u || y>v || z>w){
				System.out.println("Not Enough Resources...");
				System.exit(0);
			}
			
			Resources need = new Resources(u-x, v-y, w-z);
			
			pr.add(new Process(p_name, allot, max, need));
		}
		
		Resources avail = new Resources(A-a, B-b, C-c);
		
		int comp = 0, ind = 0, k=0;
		
		while(comp < n){
			if(ind == pr.size()) ind = ind%pr.size();
			
			Process p = pr.get(ind);
			
			if(check(total, avail, p.need)){

				k=0;
				comp++;
				
				avail.a += p.allot.a;
				avail.b += p.allot.b;
				avail.c += p.allot.c;
				
				sch.add(p.p_name);
				pr.remove(p);
			}
			else{
				k++;
				ind++;
			}
			
			if(k > n) break;
		}
		
		if(k>n) System.out.println("System goes in unsafe mode");
		else{
			System.out.println("System is in safe mode");
			System.out.println("\nScheduling of the process is ");
			
			for(String s : sch){
				System.out.print(s + " -> ");
			}
		}
		System.out.println();
		
		sc.close();
	}
	
	public static boolean check(Resources total, Resources avail, Resources curr){
		
		if(curr.a > avail.a || curr.b > avail.b || curr.c > avail.c){
			return false;
		}
		//if(curr.a+avail.a > total.a || curr.b+avail.b > total.b || curr.c+avail.c > total.c){
		//	return false;
		//}
		
		return true;
	}

}












