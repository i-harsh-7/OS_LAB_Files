import java.util.*;
import java.lang.*;

class DynamicMemAll{
	static List<String> waiting = new ArrayList<>();
	static Scanner sc = new Scanner(System.in);
	
	
	public static void main(String[] abcd){
		//Scanner sc = new Scanner(System.in);
		
		//System.out.println("");
		System.out.println("------Dynamic Memory Allocation Program ------ ");
		
		System.out.print("Enter the number of memory blocks : ");
		int numBlock = sc.nextInt();
		
		int memBlock[] = new int[numBlock];
		for(int i=0; i<numBlock; i++){
			memBlock[i] = sc.nextInt();
		}
		
		System.out.print("Enter the number of processes : ");
		int numPro = sc.nextInt();
		
		int processes[] = new int[numPro];
		for(int i=0; i<numPro; i++){
			processes[i] = sc.nextInt();
		}
		
		System.out.println("Choose the memory Allocation Strategy : \n1. Best Fit \n2. First Fit \n3. Worst Fit");
		
		int allocation[] = new int[numPro];
		int ch = sc.nextInt();
		
		while (ch < 1 || ch > 3) {
            		System.out.println("Invalid choice. Please select 1, 2, or 3.");
           	 	ch = sc.nextInt();
        	}
		
		
		switch(ch){
			case 1:
				allocation = bestFit(numBlock, memBlock, numPro, processes);
				break;
				
			case 2:
				allocation = firstFit(numBlock, memBlock, numPro, processes);
				break;
				
			case 3:
				allocation = worstFit(numBlock, memBlock, numPro, processes);
				break;
		}
		
		System.out.println("\n-----Scheduling of the processes ------");
		
		int num = 1;
		for(int i : allocation){
			if (i == 0)
                		System.out.println("Process " + num++ + " could not be allocated.");
            		else
                		System.out.println("Process " + num++ + " allocated to block " + i);
		}
		
		System.out.println("\nAvailable sizes in Memory Block ------");
		for(int i : memBlock){
			System.out.print( i + " ");
		}
		System.out.println();
		
		if (!waiting.isEmpty()) {
            		System.out.println("\nProcesses that couldn't be allocated:");
            		for (String p : waiting) {
                		System.out.println("Process " + p);
            		}
        	}
        	System.out.println();
		
		sc.close();
	}
	
	
	static int[] bestFit(int numBlock, int[] memBlock, int numPro, int[] processes) {
        int allocation[] = new int[numPro];

        for (int i = 0; i < numPro; i++) {
            int allot = -1;
            int minDiff = Integer.MAX_VALUE;

            for (int j = 0; j < numBlock; j++) {
                if (processes[i] <= memBlock[j] && (memBlock[j] - processes[i]) < minDiff) {
                    minDiff = memBlock[j] - processes[i];
                    allot = j + 1;
                }
            }

            if (allot == -1) {
                waiting.add(Integer.toString(i + 1));
            } else {
                allocation[i] = allot;
                memBlock[allot - 1] -= processes[i];
            }

            if (!waiting.isEmpty()) {
                System.out.println("\nWant to do compaction: \n1. Yes \n2. No");
                int ch = sc.nextInt();
                if (ch == 1) {
                    memBlock = compaction(numBlock, memBlock);
                }
            }
        }

        return allocation;
    }

    static int[] worstFit(int numBlock, int[] memBlock, int numPro, int[] processes) {
        int allocation[] = new int[numPro];

        for (int i = 0; i < numPro; i++) {
            int allot = -1;
            int maxDiff = -1;

            for (int j = 0; j < numBlock; j++) {
                if (processes[i] <= memBlock[j] && (memBlock[j] - processes[i]) > maxDiff) {
                    maxDiff = memBlock[j] - processes[i];
                    allot = j + 1;
                }
            }

            if (allot == -1) {
                waiting.add(Integer.toString(i + 1));
            } else {
                allocation[i] = allot;
                memBlock[allot - 1] -= processes[i];
            }

            if (!waiting.isEmpty()) {
                System.out.println("\nWant to do compaction: \n1. Yes \n2. No");
                int ch = sc.nextInt();
                if (ch == 1) {
                    memBlock = compaction(numBlock, memBlock);
                }
            }
        }

        return allocation;
    }

    static int[] firstFit(int numBlock, int[] memBlock, int numPro, int[] processes) {
        int allocation[] = new int[numPro];

        for (int i = 0; i < numPro; i++) {
            int allot = -1;

            for (int j = 0; j < numBlock; j++) {
                if (processes[i] <= memBlock[j]) {
                    allot = j + 1;
                    break;
                }
            }

            if (allot == -1) {
                waiting.add(Integer.toString(i + 1));
            } else {
                allocation[i] = allot;
                memBlock[allot - 1] -= processes[i];
            }

            if (!waiting.isEmpty()) {
                System.out.println("\nWant to do compaction: \n1. Yes \n2. No");
                int ch = sc.nextInt();
                if (ch == 1) {
                    memBlock = compaction(numBlock, memBlock);
                }
            }
        }

        return allocation;
    }

    static int[] compaction(int numBlock, int[] memBlock) {
        int remSize = 0;

        for (int i = 0; i < numBlock - 1; i++) {
            remSize += memBlock[i];
            memBlock[i] = 0;
        }

        memBlock[numBlock - 1] += remSize;
        System.out.println("\nCompaction Done. Memory Blocks after compaction:");
        for (int i : memBlock) {
            System.out.print(i + " ");
        }
        return memBlock;
    }

}








